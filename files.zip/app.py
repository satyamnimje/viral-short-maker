import re
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np
import streamlit as st
import yt_dlp
from faster_whisper import WhisperModel
from yt_dlp.utils import download_range_func

CLIP_SECONDS = 60
MAX_VIDEO_MINUTES = 60

HOOK_WORDS = ["but", "however", "secret", "mistake", "never", "always", "why", "how", "truth",
              "actually", "shocking", "crazy", "important", "problem", "warning", "nobody",
              "everyone", "wrong", "surprising", "imagine", "remember", "listen", "because",
              "the reason", "stop", "biggest", "first"]
EMOTION_WORDS = ["amazing", "terrible", "love", "hate", "fear", "excited", "angry", "shocked",
                 "beautiful", "worst", "best", "insane", "unbelievable", "danger", "fail",
                 "success", "win", "lose", "incredible", "scary", "huge"]
HOOK_RE = re.compile(r"\b(" + "|".join(map(re.escape, HOOK_WORDS)) + r")\b")
EMO_RE = re.compile(r"\b(" + "|".join(map(re.escape, EMOTION_WORDS)) + r")\b")


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"{cmd[0]} failed: {p.stderr[-400:]}")
    return p


@st.cache_resource
def load_whisper(size):
    return WhisperModel(size, device="cpu", compute_type="int8")


def download_audio(url, folder):
    opts = {"format": "bestaudio/best", "outtmpl": str(folder / "audio.%(ext)s"),
            "noplaylist": True, "quiet": True, "no_warnings": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
    return next(folder.glob("audio.*")), info


def to_wav(src, folder):
    wav = folder / "audio.wav"
    run(["ffmpeg", "-y", "-i", str(src), "-ac", "1", "-ar", "16000", str(wav)])
    return wav


def transcribe(wav, size):
    segs, _ = load_whisper(size).transcribe(str(wav), beam_size=5, vad_filter=True)
    return [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()}
            for s in segs if s.text.strip()]


def audio_energy(wav):
    with wave.open(str(wav), "rb") as w:
        rate = w.getframerate()
        a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    n = len(a) // rate
    if n == 0:
        return np.array([])
    rms = np.sqrt(np.mean(a[: n * rate].reshape(n, rate) ** 2, axis=1))
    return rms / (np.percentile(rms, 95) + 1e-9)


def text_score(text, seconds):
    t = re.sub(r"\s+", " ", text.lower()).strip()
    if len(t.split()) < 5:
        return 0.0
    raw = 3 * len(set(HOOK_RE.findall(t))) + 2 * len(set(EMO_RE.findall(t)))
    raw += 4 * t.count("?") + 3 * t.count("!")
    raw += min(len(re.findall(r"\b\d+(?:\.\d+)?\b", t)) * 1.5, 10)
    return float(min(raw / max(seconds / 30, 1) / 30 * 100, 100))


def audio_score(energy, start, end):
    seg = energy[int(start):int(end)]
    if len(seg) == 0:
        return 0.0
    return float(min((0.5 * seg.mean() + 0.5 * np.percentile(seg, 90)) * 100, 100))


def find_best_window(segs, energy, duration):
    if duration <= CLIP_SECONDS:
        starts = [0.0]
    else:
        starts = sorted({s["start"] for s in segs if s["start"] + CLIP_SECONDS <= duration}
                        | {duration - CLIP_SECONDS})
    best = None
    for start in starts:
        end = min(start + CLIP_SECONDS, duration)
        inside = [s for s in segs if s["start"] < end and s["end"] > start]
        text = " ".join(s["text"] for s in inside)
        hook_text = " ".join(s["text"] for s in inside if s["start"] < start + 6)
        ts = text_score(text, end - start)
        hs = text_score(hook_text, 6)           # strong opening = scroll-stopping hook
        au = audio_score(energy, start, end)
        wps = len(text.split()) / max(end - start, 1)
        penalty = 20 if wps < 0.5 else 10 if wps < 1.0 else 0   # dead-air penalty
        final = 0.5 * ts + 0.3 * au + 0.2 * hs - penalty
        if best is None or final > best["final"]:
            # end on a sentence boundary, but never exceed 60s
            ends = [s["end"] for s in inside if start + 52 <= s["end"] <= start + CLIP_SECONDS]
            best = {"start": start, "end": max(ends) if ends else end, "text": text,
                    "final": round(final, 1), "text_score": round(ts, 1),
                    "audio_score": round(au, 1), "hook_score": round(hs, 1)}
    return best


def make_short(url, start, end, folder, vertical):
    opts = {"format": "bestvideo[height<=1080]+bestaudio/best",
            "outtmpl": str(folder / "section.%(ext)s"), "merge_output_format": "mp4",
            "noplaylist": True, "quiet": True, "no_warnings": True,
            "download_ranges": download_range_func(None, [(start, end)]),
            "force_keyframes_at_cuts": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])
    src = next(folder.glob("section.*"))
    out = folder / "short.mp4"
    cmd = ["ffmpeg", "-y", "-i", str(src)]
    if vertical:
        cmd += ["-vf", "crop='min(iw,ih*9/16)':ih,scale=1080:1920"]
    cmd += ["-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-movflags", "+faststart", str(out)]
    run(cmd)
    return out.read_bytes()


def fmt(sec):
    sec = int(sec)
    return f"{sec // 3600:02d}:{sec % 3600 // 60:02d}:{sec % 60:02d}" if sec >= 3600 else f"{sec // 60:02d}:{sec % 60:02d}"


# ---------------- UI ----------------
st.set_page_config(page_title="Viral Short Maker", page_icon="✂️")
st.title("✂️ Viral Short Maker")
st.write("Paste a YouTube link. The app finds the most engaging ~60 seconds and cuts it into a short.")
st.warning("Use only with videos you own or have permission to download and edit.")

url = st.text_input("YouTube link", placeholder="https://www.youtube.com/watch?v=...")
c1, c2 = st.columns(2)
model_size = c1.selectbox("Transcription quality", ["tiny", "base", "small"], index=1,
                          help="tiny = fastest, small = most accurate but slower")
vertical = c2.checkbox("Vertical 9:16 (Shorts / Reels / TikTok)", value=True)

if st.button("🚀 Create my short", type="primary"):
    if not url.strip():
        st.error("Please paste a YouTube link.")
    elif not shutil.which("ffmpeg"):
        st.error("ffmpeg is not installed on this machine. See the setup notes.")
    else:
        st.session_state.pop("result", None)
        try:
            with tempfile.TemporaryDirectory() as tmp, st.status("Working...", expanded=True) as status:
                tmp = Path(tmp)
                st.write("⬇️ Downloading audio...")
                audio_file, info = download_audio(url, tmp)
                duration = float(info.get("duration") or 0)
                if duration > MAX_VIDEO_MINUTES * 60:
                    raise RuntimeError(f"Video is longer than {MAX_VIDEO_MINUTES} minutes. Try a shorter one.")
                wav = to_wav(audio_file, tmp)
                st.write("📝 Transcribing speech (slowest step)...")
                segs = transcribe(wav, model_size)
                if not segs:
                    raise RuntimeError("No speech found in this video, so it can't be ranked.")
                st.write("🔊 Scoring moments...")
                best = find_best_window(segs, audio_energy(wav), duration)
                st.write(f"✂️ Cutting {fmt(best['start'])} → {fmt(best['end'])}...")
                video_bytes = make_short(url, best["start"], best["end"], tmp, vertical)
                status.update(label="Done!", state="complete")
            st.session_state["result"] = {"title": info.get("title", "video"), "bytes": video_bytes, **best}
        except Exception as e:
            st.error(f"Could not finish: {e}")

r = st.session_state.get("result")
if r:
    st.subheader(r["title"])
    st.video(r["bytes"])
    st.download_button("⬇️ Download short", r["bytes"], file_name="viral_short.mp4", mime="video/mp4")
    st.write(f"**Best moment:** {fmt(r['start'])} → {fmt(r['end'])}  ·  **Score {r['final']}**  "
             f"(text {r['text_score']} · audio {r['audio_score']} · opening hook {r['hook_score']})")
    with st.expander("Transcript of this clip"):
        st.write(r["text"])
